// The Editor window in the apps: the website's playground, finishing with Apply and Save
// instead of Download and Copy link. The app says what to open through the address.
(async () => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const params = new URLSearchParams(location.search);
  const source = params.get("source");
  const display = params.get("display");
  const sourceName = params.get("name");
  const partial = params.get("partial") === "1";

  /** Sends a request to whichever app this page is running in. */
  function host(action, payload = {}) {
    const mac = window.webkit?.messageHandlers?.editor;
    if (mac) return mac.postMessage({ action, ...payload });
    if (window.__TAURI__) return window.__TAURI__.core.invoke(`editor_${action}`, payload);
    return Promise.reject(new Error("The Editor only runs inside the WidgetThemes app."));
  }

  const uuid = () => "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) =>
    (Number(c) ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (Number(c) / 4)))).toString(16));

  // MARK: The page

  $("#pg-share").remove();
  $("#pg-download").remove();
  $("#pg-expand").remove();
  $(".pg-toolbar").setAttribute("aria-label", "Editor controls");
  $(".pg-finish").innerHTML = `
    <div class="ed-save-box">
      <button class="chip" id="ed-save" type="button" aria-expanded="false">Save Theme</button>
      <form class="ed-popover" id="ed-save-form" hidden>
        <label>Name<input id="ed-name" maxlength="80" autocomplete="off" spellcheck="false"></label>
        <div class="row">
          <button class="chip" id="ed-save-new" type="button" hidden>Save as New</button>
          <button class="button small" type="submit">Save</button>
        </div>
      </form>
    </div>
    <button class="button small" id="ed-apply" type="button">Apply to Desktop</button>`;
  // With more than one display, it's always clear which one this is for.
  const displayName = params.get("displayName");
  if (displayName) {
    const arranging = document.createElement("span");
    arranging.className = "ed-display";
    arranging.textContent = `Arranging ${displayName}`;
    $(".pg-finish").prepend(arranging);
  }
  $(".pg-side .hint:last-child").textContent = "Readings are sample data here. Your widgets show live readings once they're on your desktop.";
  $("#pg-accent-box .hint").textContent = "A close preview: your desktop draws the exact colour.";
  $("#pg-accent-note").textContent = "This theme's accent can't be previewed here, but it's kept when you apply or save.";
  const askToSave = document.createElement("dialog");
  askToSave.className = "ed-dialog";
  askToSave.innerHTML = `
    <form method="dialog" id="ed-ask-form">
      <h2 id="ed-ask-title">Save this theme?</h2>
      <p id="ed-ask-text">Your changes are on your desktop. Save them to My Themes to come back to them later.</p>
      <label>Name<input id="ed-ask-name" maxlength="80" autocomplete="off" spellcheck="false"></label>
      <p class="ed-ask-error" id="ed-ask-error" role="alert" hidden></p>
      <div class="row">
        <button class="chip" id="ed-ask-skip" type="button">Don't Save</button>
        <button class="button small" id="ed-ask-save" type="submit">Save Theme</button>
      </div>
    </form>`;
  document.body.append(askToSave);

  // MARK: The desk

  const data = await (await fetch("assets/data/themes.json")).json();
  // The desk is the display being arranged, whose usable area has no menu bar to leave room for.
  const deskWidth = Number(params.get("deskW")), deskHeight = Number(params.get("deskH"));
  const realDesk = deskWidth >= 400 && deskHeight >= 300 && deskWidth <= 16384 && deskHeight <= 16384;
  if (realDesk) {
    data.canvas = { width: deskWidth, height: deskHeight, top: 0, real: true };
    $("#pg-stage").style.aspectRatio = `${deskWidth} / ${deskHeight}`;
    $(".pg-main").style.setProperty("--desk-ratio", deskWidth / deskHeight);
  }
  let dirty = false;
  const setDirty = (value) => {
    dirty = value;
    if (window.webkit?.messageHandlers?.editor) host("dirty", { dirty }).catch(() => {});
  };
  /** The pictures on offer. Windows and Linux hand back names, and the page makes them addresses. */
  const pictureAddress = (entry) => {
    if (entry.url) return entry;
    const url = entry.id.startsWith("extras/")
      ? `../img/extras/${encodeURIComponent(entry.id.slice(7))}`
      : window.__TAURI__.core.convertFileSrc(entry.id);
    return { ...entry, url };
  };
  const wallpapers = {
    list: async () => {
      const found = await host("wallpapers");
      return { extras: found.extras.map(pictureAddress), mine: found.mine.map(pictureAddress) };
    },
    choose: async () => {
      const entry = await host("choose_wallpaper");
      return entry ? pictureAddress(entry) : null;
    },
  };
  const desk = Playground.create(data, Playground.catalog(data), {
    onChange: () => setDirty(true),
    wallpapers,
    placedMessage: "Placed. Apply to Desktop when you're done.",
  });
  if (realDesk) $(".pg-menubar")?.remove();
  if (partial) desk.say("This desktop has more widgets than the Editor can hold, so only the first 40 are shown. Saving makes a new copy.", { stay: true });

  // Rearranging a desktop leaves its wallpaper alone unless a different one was chosen.
  const wallpaperKey = () => {
    const { state, wallpaperFile } = desk.current();
    return `${state.wallpaper || ""}|${wallpaperFile || ""}`;
  };
  let startingWallpaper = wallpaperKey();
  const wallpaperChanged = () => wallpaperKey() !== startingWallpaper;
  // The picture this desktop or saved theme already has, shown as it will be left.
  const startingFile = params.get("wallpaperFile");
  if (startingFile) {
    wallpapers.list().then(({ extras, mine }) => {
      const entry = [...extras, ...mine].find((candidate) => candidate.id === startingFile);
      if (entry && !wallpaperChanged()) {
        desk.showCustomWallpaper(entry);
        startingWallpaper = wallpaperKey();
      }
    }).catch(() => {});
  }

  /** Everything the app needs to put the desk on the desktop or in My Themes. */
  function finished(name) {
    const { state, skin, title, edited, accent, wallpaperFile } = desk.current();
    const file = LayoutShare.envelope(state, data, skin, uuid());
    file.theme.name = name || sourceName || `${title} layout`;
    return { file: JSON.stringify(file), skin, mode: state.mode, edited, accent, source, display, wallpaperFile };
  }

  /** Runs a request, keeping the button from being pressed twice, and reports how it went. */
  async function act(button, request, done) {
    button.disabled = true;
    try {
      const reply = await request();
      if (reply !== false) done(reply);
    } catch (error) {
      desk.say(String(error?.message || error), { stay: true });
    } finally {
      button.disabled = false;
    }
  }

  const tauriWindow = window.__TAURI__?.window?.getCurrentWindow?.();
  /** The Editor's work is done: nothing is left to ask about. */
  function closeWindow() {
    setDirty(false);
    if (window.webkit?.messageHandlers?.editor) host("close").catch(() => {});
    else tauriWindow?.destroy();
  }

  // Applying finishes the Editor. A built-in or saved theme with changes would lose them, so that asks first.
  const applyButton = $("#ed-apply");
  applyButton.addEventListener("click", () => act(applyButton,
    () => host("apply", { ...finished(), wallpaper: source !== "desktop" || wallpaperChanged() }),
    () => {
      const changedSaved = Boolean(source) && source !== "desktop" && dirty;
      setDirty(false);
      if (changedSaved || (!source && desk.current().edited)) {
        if (changedSaved) {
          $("#ed-ask-title").textContent = "Save changes to this theme?";
          $("#ed-ask-text").textContent = "Your changes are on your desktop. Save them to update this theme in My Themes.";
        }
        $("#ed-ask-name").value = sourceName || `${desk.current().title} layout`;
        askToSave.showModal();
        $("#ed-ask-name").select();
      } else closeWindow();
    }));

  $("#ed-ask-skip").addEventListener("click", closeWindow);
  askToSave.addEventListener("cancel", (event) => { event.preventDefault(); closeWindow(); });
  $("#ed-ask-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = $("#ed-ask-name").value.trim(), error = $("#ed-ask-error"), button = $("#ed-ask-save");
    if (!name) { $("#ed-ask-name").focus(); return; }
    button.disabled = true;
    error.hidden = true;
    try {
      await host("save", { ...finished(name), name, replace: canReplace });
      closeWindow();
    } catch (failure) {
      error.textContent = String(failure?.message || failure);
      error.hidden = false;
    } finally {
      button.disabled = false;
    }
  });

  const saveButton = $("#ed-save"), form = $("#ed-save-form"), nameField = $("#ed-name"), saveNew = $("#ed-save-new");
  const canReplace = Boolean(source) && source !== "desktop" && !partial;
  saveNew.hidden = !canReplace;
  function showForm(open) {
    form.hidden = !open;
    saveButton.setAttribute("aria-expanded", String(open));
    if (open) {
      nameField.value = sourceName || `${desk.current().title} layout`;
      nameField.select();
      nameField.focus();
    }
  }
  saveButton.addEventListener("click", () => showForm(form.hidden));
  document.addEventListener("pointerdown", (event) => {
    if (!form.hidden && !event.target.closest(".ed-save-box")) showForm(false);
  });
  form.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { event.stopPropagation(); showForm(false); saveButton.focus(); }
  });
  function save(replace) {
    const name = nameField.value.trim();
    if (!name) { nameField.focus(); return; }
    act(saveButton, () => host("save", { ...finished(name), name, replace }), () => {
      showForm(false);
      setDirty(false);
      desk.say(`Saved “${name}” to My Themes.`);
    });
  }
  form.addEventListener("submit", (event) => { event.preventDefault(); save(canReplace); });
  saveNew.addEventListener("click", () => save(false));

  // Closing with work on the desk asks first. The Mac asks from the window, knowing it's dirty.
  tauriWindow?.onCloseRequested((event) => {
    if (dirty && !window.confirm("Close without applying or saving your changes?")) event.preventDefault();
  });

  const placing = params.get("place");
  if (placing) desk.carry(placing, params.get("placeSkin"));

  // What the app's own checks use: every theme's layout has to make a valid file.
  window.PreviewEditor = {
    dirty: () => dirty,
    /** A new widget on the pointer, from the app's Widgets page. */
    place: (kind, skin) => desk.carry(kind, skin),
    everyTheme: () => Object.values(data.families).map((family) => {
      desk.load(family.id, "auto");
      return finished();
    }),
  };
})();
